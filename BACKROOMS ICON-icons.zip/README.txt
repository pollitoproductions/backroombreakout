App Icon Generator - ConvertICO.com
=====================================

Generated icons for: Android
Generated on: 5/4/2026

FOLDER STRUCTURE
================

Android/
  - mipmap-mdpi/ through mipmap-xxxhdpi/ folders
  - Copy folders directly to your app/src/main/res/ directory
  - playstore-icon.png (512x512) for Google Play Store
  - Adaptive icon assets (ic_launcher_foreground.png, ic_launcher_background.png)
  - values/colors.xml contains the background color



USAGE TIPS
==========

iOS:
- Drag icons into Xcode's asset catalog
- Xcode will automatically use correct sizes

Android:
- Copy mipmap folders to res/ directory
- For adaptive icons, add to AndroidManifest.xml:
  android:icon="@mipmap/ic_launcher"
  android:roundIcon="@mipmap/ic_launcher_round"

Web:
- Place files in your website's root directory
- Add HTML snippet to your <head> section

---
Generated with ConvertICO.com App Icon Generator
https://convertico.com/app-icon-generator/
